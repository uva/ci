import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal

from numpy import nan
from pandas import DataFrame, Series

    
def monotonously_decreasing(series):
    dec, current = True, series[0]
    for x in series[1:]:
        if x > current:
            dec = False
        current = x
    return dec
    
def test_1(costs):
    print("Testing: ", end = "")
    assert len(costs) == 100, "You didn't run the algorithm with N=100"
    assert costs[-1] < 0.02, "The final cost after running gradient descent with N=100 and alpha=0.04 should be below 0.02."
    assert monotonously_decreasing(costs), "The cost is not monotonously decreasing"
    print("success!")
    
def test_2(costs):
    print("Testing: ", end = "")
    assert costs[-1] < 0.005, "The final cost after running gradient descent should be below 0.005."
    assert monotonously_decreasing(costs), "The cost is not monotonously decreasing"
    print("success!")
    
    
def test_4(costs):
    print("Testing: ", end = "")
    assert len(costs) == 100, f"costs only has {len(cost)} values. This should be 100. Maybe you didn't run the algorithm with N=100? Or did you forget to append the cost in the second stage of the algorithm?"
    assert costs[-1] < 0.01, "The final cost after running gradient descent with N=100 and alpha=0.04 should be well below 0.01."
    assert monotonously_decreasing(costs), "The cost is not monotonously decreasing"
    print("success!")
    
    
def test_5(costs):
    print("Testing: ", end = "")
    assert costs[-1] < 0.001, "The final cost after running gradient descent should be below 0.001."
    assert monotonously_decreasing(costs), "The cost is not monotonously decreasing"
    print("success!")