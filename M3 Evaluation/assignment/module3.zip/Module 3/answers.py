import numpy as np
import pandas as pd

from numpy import nan
from pandas import DataFrame, Series


def test_1(utility, similarity):
    print('Check utility: ', end='')
    _partial_utility_solution = DataFrame(
        [[2.5, nan, nan, 4. , nan, 2.5, 4. , 2.5, nan, nan],
         [nan, nan, 3.5, nan, 4. , 4. , nan, nan, 2. , nan],
         [3.5, 4.5, nan, 5. , nan, nan, 4. , nan, 4.5, 4.5],
         [nan, 3.5, nan, 4. , nan, nan, 3. , 4. , nan, 4.5],
         [nan, 5. , 4.5, nan, 4.5, 4. , nan, 3. , 4.5, 5. ]],
        columns=[68, 105, 177, 182, 232, 600, 603, 606, 608, 610],
        index=[1, 2, 16, 32, 47])
    _partial_student_solution = utility.loc[
        [1, 2, 16, 32, 47], [68, 105, 177, 182, 232, 600, 603, 606, 608, 610]]

    np.testing.assert_allclose(_partial_student_solution,
                               _partial_utility_solution, rtol=6e-1)
    print('success!')

    print('Check similarity: ', end='')
    _partial_similarity_solution = DataFrame(
        [[ 1.        ,  0.16874289, -0.02003966, -0.09697159, -0.0223511 ],
         [ 0.16874289,  1.        , -0.48204145, -0.20451409, -0.46394874],
         [-0.02003966, -0.48204145,  1.        ,  0.1138749 ,  0.48948356],
         [-0.09697159, -0.20451409,  0.1138749 ,  1.        ,  0.44298855],
         [-0.0223511 , -0.46394874,  0.48948356,  0.44298855,  1.        ]],
                                     columns=[1, 2, 16, 32, 47],
                                     index=[1, 2, 16, 32, 47])
    
    _partial_student_solution = similarity.loc[
        [1, 2, 16, 32, 47], [1, 2, 16, 32, 47]]

    np.testing.assert_allclose(_partial_student_solution,
                               _partial_similarity_solution, rtol=6e-1)
    print('success!')


def test_2(predict_ratings_item_based, similarity_items, utility_items, test_data):
    print('Computing solution: ', end='')
    _partial_solution = DataFrame(
        [[68, 2, 3.4879827138689024], [68, 47, 3.457850808877052],
         [68, 110, 3.625071363263896], [68, 344, 3.4579973887255604],
         [68, 593, 3.4942987600576014]],
        columns=['userId', 'movieId', 'predicted rating'],
        index=[1, 3, 6, 14, 27])
    _student_solution = predict_ratings_item_based(similarity_items,
                                                   utility_items, test_data[
                                                       ['userId', 'movieId',
                                                        'rating']]).head()

    print('success!')

    print('Testing layout of prediction: ', end='')
    for column in ['userId', 'movieId', 'predicted rating']:
        assert column in _student_solution.columns, f'expected column {column} in output'

    print('success!')

    print('Testing values of prediction: ', end='')
    np.testing.assert_allclose(_student_solution, _partial_solution, rtol=2e-1)
    print('success!')


def test_3(mse, actual, predicted_item_based):
    print('Testing mse item based: ', end='')
    np.testing.assert_allclose(mse(actual, predicted_item_based), 0.6, rtol=0.15)
    print('success!')


def test_4(mse, actual, predicted_user_based, predicted_item_based):
    print('Testing user based versus item based prediction: ', end='')
    assert mse(actual, predicted_user_based) > mse(
        actual, predicted_item_based), "expected a slightly lower error for item based prediction"
    print('success!')


def test_5(mse_random):
    print('Testing: ', end='')
    _student_solution = mse_random
    _solution = 3.3
    assert np.allclose(_student_solution, _solution,
                       atol=0.5), f'expected value around {_solution}'
    print('success!')


def test_6(mse_item_mean):
    print('Testing: ', end='')
    _student_solution = mse_item_mean
    _solution = 0.68
    assert np.allclose(_student_solution, _solution,
                       atol=0.2), f'expected value around {_solution}'
    print('success!')


def test_8(recommended, hidden, predicted_item_based, treshold_recommended):
    print('Testing: ', end='')
    tol = 5

    recommended_items_solution = 448
    recommended_items = recommended(predicted_item_based,
                                    treshold_recommended).shape[0]

    assert abs(recommended_items - recommended_items_solution) < tol, f'expected value around {recommended_items_solution}'

    hidden_items_solution = 545
    hidden_items = hidden(predicted_item_based, treshold_recommended).shape[0]

    assert abs(hidden_items - hidden_items_solution) < tol, f'expected value around {hidden_items_solution}'

    print('success!')


def test_9(used, unused, actual, treshold_used):
    print('Testing: ', end='')
    tol = 5

    used_items_solution = 503
    used_items = used(actual, treshold_used).shape[0]

    assert abs(used_items_solution - used_items) < tol, f'expected value around {used_items_solution}'

    unused_items_solution = 490
    unused_items = unused(actual, treshold_used).shape[0]

    assert abs(unused_items_solution - unused_items) < tol, f'expected value around {unused_items_solution}'

    print('success!')


def test_10(confusion_matrix):
    print('Testing: ', end='')
    solution = DataFrame([[314, 134], [189, 356]], columns=['used', 'unused'],
                         index=['recommended', 'hidden'])

    pd.testing.assert_frame_equal(confusion_matrix, solution,
                                  check_names=False, check_like=True, check_frame_type=False, 
                                  check_index_type=False, check_column_type=False)
    print('success!')


def test_11(precision_item_based):
    print('Testing: ', end='')
    _student_solution = precision_item_based
    _solution = 0.7
    assert np.allclose(_student_solution, _solution,
                       atol=0.2), f'expected value around {_solution}'
    print('success!')


def test_12(recall_item_based):
    print('Testing: ', end='')
    _student_solution = recall_item_based
    _solution = 0.62
    assert np.allclose(_student_solution, _solution,
                       atol=0.2), f'expected value around {_solution}'
    print('success!')
