import numpy as np
import pandas as pd

def number_of_movies(ratings: pd.DataFrame) -> int:
    """ determine the number of unique movie id's in the data """
    return len(ratings['movieId'].unique())


def number_of_users(ratings: pd.DataFrame) -> int:
    """ determine the number of unique user id's in the data """
    return len(ratings['userId'].unique())


def number_of_ratings(ratings: pd.DataFrame) -> int:
    """ count the number of ratings of a dataset """
    return ratings.shape[0]


def rating_density(ratings: pd.DataFrame) -> float:
    """ compute the ratings given a data set """
    return number_of_ratings(ratings) / (number_of_movies(ratings) * number_of_users(ratings))


def split_data(data: pd.DataFrame, d: int = 0.75) -> tuple[pd.DataFrame, pd.DataFrame]:
    """ split data in a training and test set 
       `d` is the fraction of data in the training set"""
    np.random.seed(seed=5)
    mask_test = np.random.rand(data.shape[0]) < d
    return data[mask_test], data[~mask_test]
