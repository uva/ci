from sklearn.metrics.pairwise import cosine_similarity as cosine_similarity_sklearn
import pandas as pd,numpy as np
def pivot_ratings(ratings):return ratings.pivot(index='movieId',columns='userId',values='rating')
def fill_nan_mean(matrix):A=matrix;B=A.mean(axis=1,skipna=True);C=A.T.fillna(B).T;D=C.fillna(0);return D
def create_similarity_matrix_cosine(utility_matrix):A=utility_matrix;B=np.array(A);C=cosine_similarity_sklearn(B);D=pd.DataFrame(data=C[0:,0:],index=A.index,columns=A.index);return D
def mean_center_columns(matrix):A=matrix;return A-A.mean(axis=0)
def select_neighborhood(similarities,ratings,k):B=ratings;A=similarities;return A[A[A>0].index.intersection(B[~B.isna()].index)][:k]
def weighted_mean(neighborhood,ratings):
	B=neighborhood;A=B*ratings;A=A[~A.isna()]
	if len(A)<=0:return np.nan
	return A.sum()/B[A.index].sum()
def mean_center_rows(matrix):return mean_center_columns(matrix.T).T